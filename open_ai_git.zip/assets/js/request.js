var base_url = "http://localhost/open_ai/";


$("#ai_generator_form").submit(function (e) {

	var requestType = $("#type").val();

	var requestUrl = base_url + 'website/ask_openai_by_curl';

	if (requestType == 'sdk') {
		var requestUrl = base_url + 'website/ask_openai_by_sdk';
	}

	$("#generate_error").html('');
	$('#generate_button').prop("disabled", true);
	$('#btn_ld_spin').removeClass('d-none');
	e.preventDefault();

	$.ajax({
		url: requestUrl,
		method: 'POST',
		dataType: 'Json',
		data: $('#ai_generator_form').serialize(),
		success: function (data) {
			//Display success messsage
			//$("#ai_output").html(data.content);            


			if (data.error == false) {
				simulateTyping(data.content, 10);
			} else {
				$('#generate_button').prop("disabled", false);
				$('#btn_ld_spin').addClass('d-none');
				$("#generate_error").html(data.message);
			}
		},
		error: function (data) {
			//Display error message
			$('#generate_button').prop("disabled", false);
			$('#btn_ld_spin').addClass('d-none');
			$("#generate_error").html('something went wrong please try again.');
		}
	});
});


function simulateTyping(htmlText, speedMultiplier = 1) {
	const baseTypingSpeedMin = 30;
	const baseTypingSpeedMax = 70;

	// Ensure speedMultiplier is not zero or negative to avoid division by zero.
	speedMultiplier = Math.max(speedMultiplier, 0.1); // Ensure it's at least 0.1

	const typingSpeedMin = Math.max(1, baseTypingSpeedMin / speedMultiplier); // Ensure it's at least 1
	const typingSpeedMax = Math.max(1, baseTypingSpeedMax / speedMultiplier); // Ensure it's at least 1


	const aiOutputDiv = $("#ai_output");

	if (typeof htmlText !== 'string' || htmlText === null || htmlText === undefined) {
		console.error("Error: simulateTyping() called with invalid htmlText:", htmlText);
		aiOutputDiv.html("Error: Could not display message.");
		return;
	}

	let i = 0;

	const typingInterval = setInterval(() => {
		if (i < htmlText.length) {
			let randomTypingSpeed = Math.floor(Math.random() * (typingSpeedMax - typingSpeedMin + 1)) + typingSpeedMin;
			aiOutputDiv.html(htmlText.substring(0, i + 1));
			i++;
			scrollToBottom();
		} else {
			clearInterval(typingInterval);
			$('#generate_button').prop("disabled", false);
			$('#btn_ld_spin').addClass('d-none');
		}
	}, Math.random() * (typingSpeedMax - typingSpeedMin) + typingSpeedMin);
}


function scrollToBottom() {
	const aiOutputDiv = $("#ai_output");
	aiOutputDiv.scrollTop(aiOutputDiv[0].scrollHeight);
}
