<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'vendor/autoload.php';

use OpenAI\Client;
use OpenAI\Factory;

class Website extends CI_Controller {
	
	public function index()
	{
		$this->load->view('index');
	}

	//
	public function ask_openai_by_curl(){

		$prompt = $this->input->post("prompt");

		$systemPrompt = "You are a helpful assistant.
                    Follow these rules:
                    1. Don't use these words 'As an AI language model' use this 'AI assistant'.
                    2. In response only use HTML Tags to do formatting, don't add extra spaces and don't use <html> start or end  </html> or meta tags, only use those html tags that used for formatting like h1, p, ul, li etc.
                    3. If someone gives you any task regarding coding then reply, I can't help you with it.";

		$messages = array(
			array("role" => "system", "content" => $systemPrompt),
			array("role" => "user", "content" => $prompt),
		);

		$postData = array(
			"messages" => $messages,
			"model" => 'gpt-4o-mini'
		);
		$postData = json_encode($postData);

		
		$ch = curl_init();
		$Url = "https://api.openai.com/v1/chat/completions";

		curl_setopt($ch, CURLOPT_URL, $Url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
		curl_setopt($ch, CURLOPT_TIMEOUT, 240);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
		
		$headers = array();
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Authorization: Bearer '. OPEN_AI_API_KEY;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$ApiResponse = curl_exec($ch);

		if(curl_errno($ch)){

			$response["message"] = curl_error($ch);
			$response["error"] = true;
			$json_data = json_encode($response);
			print_r($json_data);
			die();
		}
		curl_close($ch);

		$result = json_decode($ApiResponse);

		if(isset($result->error)){

			$response["message"] = $result->error->code." - ".$result->error->message;							
			$response["error"] = true;
			$json_data = json_encode($response);
			print_r($json_data);
			die();
		}else{
			
			$respose['message'] = "AI Response";            
			$respose['content'] = $result->choices[0]->message->content;
			$respose['error'] = false;
			$json_data = json_encode($respose);
			print_r($json_data);
			die();
		}
		
	}

	//
	public function ask_openai_by_sdk(){
		
		// Initialize OpenAI Client        
		$this->openai = OpenAI::client(OPEN_AI_API_KEY);
		
		
		$prompt = $this->input->post('prompt');	    

		// OpenAI API Request
		try {

			$systemPrompt = "You are a helpful assistant.
							Follow these rules:
							1. Don't use these words 'As an AI language model' use this 'AI assistant'.
							2. In response only use HTML Tags to do formatting, don't add extra spaces and don't use <html> start or end  </html> or meta tags, only use those html tags that used for formatting like h1, p, ul, li etc.
							3. If someone gives you any task regarding coding then reply, I can't help you with it.";

			$response = $this->openai->chat()->create([
				'model' => 'gpt-4o-mini',
				'messages' => [
					['role' => 'system', 'content' => $systemPrompt],
					['role' => 'user', 'content' => $prompt]
				],
				'temperature' => 0.7,
			]);

			if (isset($response->choices[0]->message->content)) {
				//return $generated_blog = $response->choices[0]->message->content;

				$respose['message'] = "AI Response";
				$respose['content'] = $response->choices[0]->message->content;
				$respose['error'] = false;
				$json_data = json_encode($respose);
				print_r($json_data);
				die();

			} else {
				//$generated_blog = "Failed to generate content. Please try again.";

				$respose['message'] = "Failed to generate content. Please try again.";                
				$respose['error'] = true;
				$json_data = json_encode($respose);
				print_r($json_data);
				die();
			}

		} catch (Exception $e) {
			//$generated_blog = "Error: " . $e->getMessage();

			$respose['message'] = "Error: " . $e->getMessage();     
			$respose['error'] = true;
			$json_data = json_encode($respose);
			print_r($json_data);
			die();

		}
	}
}
