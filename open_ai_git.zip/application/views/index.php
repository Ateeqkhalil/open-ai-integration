<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Integrate OpenAI API in PHP</title>
		<meta name="description" content="Integrate OpenAI API in PHP CodeIgniter  Step-by-Step guide">
		<!-- Bootstrap CSS -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
		<!-- Font Awesome CSS (for Icons) -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
		<link rel="stylesheet" href="<?= base_url('assets/css/style.css')?>">
		<link rel="stylesheet" href="<?= base_url('assets/css/loading.min.css')?>">
	</head>

	<body>

		<div class="px-4 py-5 my-5 text-center">
			<img class="d-block mx-auto mb-4" src="<?= base_url('assets/img/openai-svgrepo-com.svg')?>" alt="" width="72" height="57">
			<h1 class="display-5 fw-bold">OpenAI API in PHP CodeIgniter</h1>
			<div class="col-lg-6 mx-auto">
				<p class="lead mb-4">Integrate OpenAI API in PHP CodeIgniter Step-by-Step guide</p>
			</div>
		</div>

		<div class="openai-request-section mb-5">
			<div class="container">
				<h2 class="mb-5"><i class="fas fa-pen-nib text-purple me-2"></i> Test OpenAI API</h2>

				<div class="openai-request-container">
					<!-- Input Section -->
					<div class="request-input-card">
						<form id="ai_generator_form">
							
							<label for="type">Request Type</label>
							<select id="type" name="type" required>
								<option value="">Choose Type</option>
								<option value="curl">Curl</option>
								<option value="sdk">OpenAI PHP SDK</option>
							</select>

							<label for="prompt">Prompt</label>
							<textarea id="prompt" name="prompt" placeholder="Enter prompt here..." required></textarea>


							<button class="generate-button" id="generate_button"><span class="ld ld-hourglass ld-spin-fast ld-font-size d-none" id="btn_ld_spin"></span> Send Request to OpenAI</button>

							<div id="generate_error" class="text-danger fw-600 mt-2"></div>

						</form>
					</div>

					<!-- Output Section -->
					<div class="request-output-card">
						<div class="d-flex justify-content-between mb-2">
							<div>
								<h5>Generated Content</h5>
							</div>
						</div>
						<div class="openai-request-output" id="ai_output">
							<p>Your AI generated text will appear here...</p>
						</div>
					</div>
				</div>
			</div>
		</div>


		<div class="floating-button-container">
			<a href="#" class="floating-button">
		  Design by Ateeq Khalil
		</a>
		</div>
		<!-- Bootstrap Bundle with Popper -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
		<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
		<script src="<?= base_url('assets/js/request.js')?>"></script>

	</body>

</html>
